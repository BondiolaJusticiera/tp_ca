#!/bin/bash
# backup_full.sh - Script de backup completo
# Grupo 7 [Enzo Caporali, Hector Moreno, Tomas Muñoz Noto, Carlos Emanuel Orlandini]
# Fecha: [14-06-25]

# Funcion de ayuda
mostrar_ayuda(){
	echo "Uso: $0 -o <origen> -d <destino>"
	echo "Opciones:"
	echo " -o <origen>  Directorio a hacer el buckup"
	echo " -d <destino> Directorio donde guardo el backup"
	echo " -h, -help    Mostrar ayuda"
	exit 1
}

#Validar argumentos

while [["$#" -gt 0 ]]; do
	case $1 in
		-o) ORIGEN="$2"; shift ;;
		-d) DESTINO="$2"; shift ;;
		-h|-help) mostrar_ayuda ;;
		*) echo "Opcion desconocida: $1"; mostrar_ayuda ;;
	esac
	shift
done

# Validar que origen y destino esten definidos
if [[ -z "$ORIGEN" || -z "DESTINO" ]]; then
	echo "Error: Tenes que elegir origen y destino"
	mostrar_ayuda
fi

#Validar que el directorio de origen existe
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen '$ORIGEN' no existe"
	exit 1
fi

#Validar que el directorio destino existe
if [[ ! -d "$DESTINO" ]]; then
	echo "El directorio de destino '$DESTINO' no existe, se intentara crear..."
	mkdir -p "$DESTINO"
	if [[ $? -ne 0 ]]; then
		echo "Error: No se pudo crear el directorio de destino pedido"
		exit 1
	else
		echo "Directorio de destino creado correctamente"
	fi
fi

#Obtener el nombre del directorio origen y fecha
NOMBRE_DIR=$(basename "ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

# Crear el backup
tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")"
"$NOMBRE_DIR"

# Verificar exito
if [[ $? -eq 0 ]]; then
	echo "Backup exitoso: $DESTINO/$ARCHIVO"
else
	echo " Error al crear el backup"
	exit 1
fi






















 
