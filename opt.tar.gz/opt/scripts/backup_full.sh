#!/bin/bash

show_help() {
    echo "Uso: $0 [origen] [destino]"
    echo ""
    echo "Este script realiza un backup comprimido del directorio de origen especificado"
    echo "y lo guarda en el destino indicado, con nombre que incluye la fecha (YYYYMMDD)."
    echo ""
    echo "Argumentos:"
    echo "  origen     Directorio que se desea respaldar."
    echo "  destino    Directorio donde se almacenará el archivo de backup."
    echo ""
    echo "Opciones:"
    echo "  -help      Muestra esta ayuda."
}

validate_paths() {
    if [ ! -d "$1" ]; then
        echo "Error: El directorio de origen '$1' no existe."
        exit 1
    fi
    if [ ! -d "$2" ]; then
        echo "Error: El directorio de destino '$2' no existe."
        exit 1
    fi
}

create_backup() {
    origen="$1"
    destino="$2"
    fecha=$(date +%Y%m%d)
    nombre_dir=$(basename "$origen")
    archivo="${nombre_dir}_bkp_${fecha}.tar.gz"
    tar -czf "${destino}/${archivo}" -C "$(dirname "$origen")" "$nombre_dir"
    echo "Backup creado exitosamente: ${destino}/${archivo}"
}

# MAIN
if [ "$1" == "-help" ]; then
    show_help
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: Número incorrecto de argumentos."
    show_help
    exit 1
fi

validate_paths "$1" "$2"
create_backup "$1" "$2"
























 
